const canvas=document.getElementById('canvas'),ctx=canvas.getContext('2d');
function resize(){canvas.width=innerWidth;canvas.height=innerHeight}addEventListener('resize',resize);resize();
class Particle{constructor(x,y){this.ox=x;this.oy=y;this.x=x+(Math.random()-.5)*120;this.y=y+(Math.random()-.5)*120;this.vx=0;this.vy=0;this.r=Math.random()*1.8+.8;}update(t){const p=1+Math.sin(t*.002)*.03;const tx=canvas.width/2+(this.ox-canvas.width/2)*p,ty=canvas.height/2+(this.oy-canvas.height/2)*p;let dx=tx-this.x,dy=ty-this.y;this.vx+=dx*.01;this.vy+=dy*.01;this.vx*=.88;this.vy*=.88;this.x+=this.vx;this.y+=this.vy;ctx.beginPath();ctx.shadowBlur=12;ctx.shadowColor='#ff4fa3';ctx.fillStyle='#ff4fa3';ctx.arc(this.x,this.y,this.r,0,Math.PI*2);ctx.fill();}}
function heart(t){return{x:16*Math.sin(t)**3,y:13*Math.cos(t)-5*Math.cos(2*t)-2*Math.cos(3*t)-Math.cos(4*t)}}
const particles=[],S=18;
for(let l=1;l>=.08;l-=.04){for(let i=0;i<500;i++){let t=i/500*Math.PI*2,p=heart(t);particles.push(new Particle(canvas.width/2+p.x*S*l,canvas.height/2-p.y*S*l));}}
(function anim(time){ctx.clearRect(0,0,canvas.width,canvas.height);for(const p of particles)p.update(time);requestAnimationFrame(anim)})(0);